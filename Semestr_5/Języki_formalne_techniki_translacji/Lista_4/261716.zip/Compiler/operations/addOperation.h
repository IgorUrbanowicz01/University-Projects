#ifndef ADDOPERATION_H
#define ADDOPERATION_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "..//codeGen/code.h"

void add_Operation_to_list(struct CodeList *list, char *file);

#endif
